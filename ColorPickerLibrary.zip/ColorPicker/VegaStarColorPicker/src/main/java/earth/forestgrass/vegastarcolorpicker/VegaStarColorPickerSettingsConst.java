package earth.forestgrass.vegastarcolorpicker;

/**
 * Created by Tatyana Klimanova on 24.06.2017.
 */

public class VegaStarColorPickerSettingsConst {
    public static String CURRENT_COLOR_MESSAGE = "CURRENT_COLOR_MESSAGE";
    public static String SELECTED_COLOR_MESSAGE = "SELECTED_COLOR_MESSAGE";
    public static String SELECT_COLOR_MESSAGE = "SELECT_COLOR_MESSAGE";
    public static String SELECT_ALPHA_MESSAGE = "SELECT_ALPHA_MESSAGE";

    public static String OK_BUTTON_TEXT = "OK_BUTTON_TEXT";
    public static String OK_BUTTON_COLOR = "OK_BUTTON_COLOR";
    public static String OK_BUTTON_TEXT_COLOR = "OK_BUTTON_TEXT_COLOR";

    public static String COLOR_ON_START = "COLOR_ON_START";

    public static String ALPHA_SUPPORT = "ALPHA_SUPPORT";
    public static int ALPHA_SUPPORT_NO = 0;
    public static int ALPHA_SUPPORT_YES = 1;
}
