package earth.forestgrass.vegastarcolorpicker;

/**
 * Created by Tatyana Klimanova on 25.06.2017.
 */

class VegaStarColorPickerConst {
    public final static String LOG_TAG = "VegaStarColorPicker";
}
