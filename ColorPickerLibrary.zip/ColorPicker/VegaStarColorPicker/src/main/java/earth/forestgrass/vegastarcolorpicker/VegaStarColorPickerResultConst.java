package earth.forestgrass.vegastarcolorpicker;

/**
 * Created by Tatyana Klimanova on 24.06.2017.
 */

public class VegaStarColorPickerResultConst {
    public static String ALPHA = "ALPHA";
    public static String RED = "RED";
    public static String GREEN = "GREEN";
    public static String BLUE = "BLUE";
    public static String HEX_HTML = "HEX_HTML";
    public static String HEX_CODE = "HEX_CODE";
}
